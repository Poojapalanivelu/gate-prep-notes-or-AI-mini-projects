# Python Learning Repository

This repository contains beginner Python programs for practice and concept understanding.

## Topics:
- Variables and Data Types
- Conditions and Loops
- Functions
- Lists and Dictionaries
