# GATE CS Preparation Notes

This repository contains my notes and study material for GATE 2027, targeting M.Tech in AI & DS at IIT.

## Subjects Covered:
- Discrete Mathematics
- Data Structures & Algorithms
- Operating Systems
- DBMS
- Computer Networks
- COA
- Theory of Computation
