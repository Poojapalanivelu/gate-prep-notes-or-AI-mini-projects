# Discrete Mathematics Notes

## Sets
- A set is a well-defined collection of objects.
- Example: A = {1, 2, 3}

## Set Operations
- Union: A ∪ B
- Intersection: A ∩ B
- Difference: A - B

## Venn Diagram Example
Let A = {1, 2}, B = {2, 3}
- A ∪ B = {1, 2, 3}
- A ∩ B = {2}
